import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpService } from '../../shared/services/http.service';

@Component({
  selector: 'app-weatherdetails',
  templateUrl: './weatherdetails.component.html',
  styleUrls: ['./weatherdetails.component.css']
})
export class WeatherdetailsComponent implements OnInit {
  weatherDetails;
  constructor(private route: ActivatedRoute, private http: HttpService) { }

  ngOnInit() {
    this.route.queryParams.subscribe((res) => {
      this.http.readData(res.city).subscribe((data) => {
        this.weatherDetails = data;       
      })
    })
  }

}
