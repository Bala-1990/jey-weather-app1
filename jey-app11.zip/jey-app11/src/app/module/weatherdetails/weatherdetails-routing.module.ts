import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WeatherdetailsComponent } from './weatherdetails.component';

const routes: Routes = [{
  path:'',
  component:WeatherdetailsComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WeatherdetailsRoutingModule { }
